# Event Management Website

## Features
- Event creation
- Participant registration
- Event list
- Basic event analytics
- MySQL database
- Java Spring Boot backend
- HTML, CSS and JavaScript frontend

## Requirements
- JDK 17+
- Maven
- MySQL

## Database
Create the database in MySQL:

CREATE DATABASE event_management;

Then edit `src/main/resources/application.properties` if your MySQL username/password are different.

## Run
From the project folder:

mvn spring-boot:run

Open:

http://localhost:8080

The `schema.sql` file creates the required tables automatically.

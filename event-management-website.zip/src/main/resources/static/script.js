const api = "/api";

async function loadEvents() {
    const response = await fetch(api + "/events");
    const events = await response.json();

    const container = document.getElementById("events");
    const select = document.getElementById("eventId");

    container.innerHTML = "";
    select.innerHTML = '<option value="">Select event</option>';

    events.forEach(event => {
        container.innerHTML += `
            <div class="event">
                <h3>${event.name}</h3>
                <p><b>Date:</b> ${event.date}</p>
                <p><b>Location:</b> ${event.location || "Not specified"}</p>
                <p>${event.description || ""}</p>
                <p><b>Capacity:</b> ${event.capacity}</p>
            </div>`;

        select.innerHTML += `<option value="${event.id}">${event.name}</option>`;
    });
}

async function loadAnalytics() {
    const response = await fetch(api + "/analytics");
    const data = await response.json();
    document.getElementById("totalEvents").textContent = data.totalEvents;
    document.getElementById("totalRegistrations").textContent = data.totalRegistrations;
}

document.getElementById("eventForm").addEventListener("submit", async e => {
    e.preventDefault();

    const event = {
        name: document.getElementById("eventName").value,
        date: document.getElementById("eventDate").value,
        location: document.getElementById("location").value,
        description: document.getElementById("description").value,
        capacity: Number(document.getElementById("capacity").value)
    };

    const response = await fetch(api + "/events", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(event)
    });

    document.getElementById("message").textContent =
        response.ok ? "Event created successfully!" : "Could not create event.";

    if (response.ok) {
        e.target.reset();
        await loadEvents();
        await loadAnalytics();
    }
});

document.getElementById("registrationForm").addEventListener("submit", async e => {
    e.preventDefault();

    const data = {
        eventId: Number(document.getElementById("eventId").value),
        participantName: document.getElementById("participantName").value,
        email: document.getElementById("email").value
    };

    const response = await fetch(api + "/registrations", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(data)
    });

    document.getElementById("message").textContent =
        response.ok ? "Registration successful!" : "Registration failed.";

    if (response.ok) {
        e.target.reset();
        await loadAnalytics();
    }
});

loadEvents();
loadAnalytics();

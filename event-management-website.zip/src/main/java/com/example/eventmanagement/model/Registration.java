package com.example.eventmanagement.model;

public class Registration {
    private int id;
    private int eventId;
    private String participantName;
    private String email;

    public Registration() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getEventId() { return eventId; }
    public void setEventId(int eventId) { this.eventId = eventId; }

    public String getParticipantName() { return participantName; }
    public void setParticipantName(String participantName) {
        this.participantName = participantName;
    }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}

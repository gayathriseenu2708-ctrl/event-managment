package com.example.eventmanagement.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class RegistrationRepository {
    private final JdbcTemplate jdbc;

    public RegistrationRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public int save(int eventId, String name, String email) {
        return jdbc.update(
            "INSERT INTO registrations(event_id,participant_name,email) VALUES(?,?,?)",
            eventId, name, email
        );
    }

    public int count() {
        Integer value = jdbc.queryForObject(
            "SELECT COUNT(*) FROM registrations", Integer.class);
        return value == null ? 0 : value;
    }

    public int countForEvent(int eventId) {
        Integer value = jdbc.queryForObject(
            "SELECT COUNT(*) FROM registrations WHERE event_id=?",
            Integer.class, eventId);
        return value == null ? 0 : value;
    }
}

package com.example.eventmanagement.repository;

import com.example.eventmanagement.model.Event;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class EventRepository {
    private final JdbcTemplate jdbc;

    public EventRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<Event> findAll() {
        return jdbc.query(
            "SELECT * FROM events ORDER BY date",
            (rs, rowNum) -> new Event(
                rs.getInt("id"),
                rs.getString("name"),
                rs.getString("date"),
                rs.getString("location"),
                rs.getString("description"),
                rs.getInt("capacity")
            )
        );
    }

    public int save(Event e) {
        return jdbc.update(
            "INSERT INTO events(name,date,location,description,capacity) VALUES(?,?,?,?,?)",
            e.getName(), e.getDate(), e.getLocation(),
            e.getDescription(), e.getCapacity()
        );
    }

    public boolean exists(int id) {
        Integer count = jdbc.queryForObject(
            "SELECT COUNT(*) FROM events WHERE id=?", Integer.class, id);
        return count != null && count > 0;
    }
}

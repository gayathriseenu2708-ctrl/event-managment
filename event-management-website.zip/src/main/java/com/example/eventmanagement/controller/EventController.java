package com.example.eventmanagement.controller;

import com.example.eventmanagement.model.Event;
import com.example.eventmanagement.repository.EventRepository;
import com.example.eventmanagement.repository.RegistrationRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class EventController {
    private final EventRepository eventRepo;
    private final RegistrationRepository registrationRepo;

    public EventController(EventRepository eventRepo,
                           RegistrationRepository registrationRepo) {
        this.eventRepo = eventRepo;
        this.registrationRepo = registrationRepo;
    }

    @GetMapping("/events")
    public List<Event> getEvents() {
        return eventRepo.findAll();
    }

    @PostMapping("/events")
    public ResponseEntity<?> createEvent(@RequestBody Event event) {
        if (event.getName() == null || event.getName().isBlank()
                || event.getDate() == null || event.getDate().isBlank()) {
            return ResponseEntity.badRequest().body("Event name and date are required.");
        }

        eventRepo.save(event);
        return ResponseEntity.ok(Map.of("message", "Event created successfully"));
    }

    @PostMapping("/registrations")
    public ResponseEntity<?> register(@RequestBody Map<String, Object> data) {
        int eventId = ((Number) data.get("eventId")).intValue();
        String name = String.valueOf(data.get("participantName"));
        String email = String.valueOf(data.get("email"));

        if (!eventRepo.exists(eventId) || name.isBlank() || email.isBlank()) {
            return ResponseEntity.badRequest().body("Invalid registration details.");
        }

        registrationRepo.save(eventId, name, email);
        return ResponseEntity.ok(Map.of("message", "Registration successful"));
    }

    @GetMapping("/analytics")
    public Map<String, Object> analytics() {
        List<Event> events = eventRepo.findAll();
        int registrations = registrationRepo.count();

        Map<String, Object> result = new HashMap<>();
        result.put("totalEvents", events.size());
        result.put("totalRegistrations", registrations);

        return result;
    }
}
